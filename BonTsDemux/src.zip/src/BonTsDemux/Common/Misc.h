#pragma once

class CMisc
{
public:
	CMisc(void);
	~CMisc(void);

	static const wchar_t* GetUsage();
	static const wchar_t* GetVersion();
};
