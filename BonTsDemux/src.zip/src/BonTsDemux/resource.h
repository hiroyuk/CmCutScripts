//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BonTsDemux.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_BONTSDEMUX_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_TSPATH                      1000
#define IDC_BROWSETS                    1001
#define IDC_VIDEOOUT                    1002
#define IDC_AUDIOOUT                    1003
#define IDC_VIDEOPATH                   1005
#define IDC_AUDIOPATH                   1006
#define IDC_VIDEOPATH2                  1006
#define IDC_FOLDERPATH                  1006
#define IDC_PROGRESS                    1007
#define IDC_BROWSEVIDEO                 1008
#define IDC_BROWSEAUDIO                 1009
#define IDC_BROWSEFOLDER                1009
#define IDC_START                       1010
#define IDC_STOP                        1011
#define IDC_INFOVIEW                    1012
#define IDC_AACDECODE                   1013
#define IDC_LIPSYNC                     1014
#define IDC_COMBO1                      1015
#define IDC_BATCH_LIST                  1016
#define IDC_BATCH_ADD                   1017
#define IDC_BATCH_DEL                   1018
#define IDC_COMBO_SOUND                 1020
#define IDC_COMBO_AUDIOES               1021
#define IDC_BUTTON_REPLACE              1022
#define IDC_SVCOMBO                     1023
#define IDC_SERVICE_REFLESH             1024
#define IDC_CHECK_RF64                  1025
#define IDC_FRAME_HOKAN                 1026
#define IDC_AUDIO_DELAY                 1027
#define IDC_DESCRAMBLE                  1028
#define IDC_CHECK1                      1029
#define IDC_USE_BACKGROUND_MODE         1030
#define IDS_HELPMESSAGE					1031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
